const fs = require("fs");
const path = require("path");

function openKS(filePath) {
    if (!fs.existsSync(filePath)) {
        console.log("File not found:", filePath);
        return;
    }

    console.log(`\n=== Open KS Menu: ${path.basename(filePath)} ===`);
    console.log("Available commands:");
    console.log("1. Open KS");
    console.log("2. Rename KS");
    console.log("3. Export KS");
    console.log("4. Delete KS");
    console.log("5. List Commands");
    console.log("6. Run KS");
    console.log("7. Hide KS");
    console.log("8. Unhide KS");
    console.log("9. Check Files");
    console.log("============================\n");

    // Example: execute command by typing number
    const stdin = process.stdin;
    stdin.setEncoding("utf-8");
    stdin.once("data", (choice) => {
        choice = choice.trim();
        switch (choice) {
            case "1":
                console.log(`[OPEN KS] ${filePath}`);
                break;
            case "2":
                console.log(`[RENAME KS] Please enter new name...`);
                break;
            case "3":
                console.log(`[EXPORT KS] ${filePath}`);
                break;
            case "4":
                console.log(`[DELETE KS] ${filePath}`);
                break;
            case "5":
                console.log(`[LIST COMMANDS] See backend for full list`);
                break;
            case "6":
                console.log(`[RUN KS] Executing with ks_engine.py`);
                break;
            case "7":
                console.log(`[HIDE KS] ${filePath}`);
                break;
            case "8":
                console.log(`[UNHIDE KS] ${filePath}`);
                break;
            case "9":
                console.log(`[CHECK FILES] ${filePath}`);
                break;
            default:
                console.log("Invalid choice");
        }
        stdin.end();
    });
}

module.exports = { openKS };
