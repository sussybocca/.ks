function ksRename(oldName, newName) {
  console.log(`[FRONTEND] Rename ${oldName} -> ${newName}`);
}

function ksExport(file) {
  console.log(`[FRONTEND] Export ${file}`);
}

function ksImport(file) {
  console.log(`[FRONTEND] Import ${file}`);
}

function ksListCommands() {
  console.log("[FRONTEND] Commands: import all, export all, ks rename, ks delete, ks hide, ks unhide, ks run, ks check files");
}
