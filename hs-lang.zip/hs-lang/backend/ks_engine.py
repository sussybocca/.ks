import os
from commands import execute_command
from errors import ErrorHandler

class KsEngine:
    def __init__(self, project_path):
        self.project_path = project_path
        self.error_handler = ErrorHandler()
        self.files = self.scan_files()

    def scan_files(self):
        ks_files = []
        for root, _, files in os.walk(self.project_path):
            for file in files:
                if file.endswith(".ks"):
                    ks_files.append(os.path.join(root, file))
        return ks_files

    def run_file(self, file_path):
        if not os.path.exists(file_path):
            self.error_handler.raise_error(40645, file_path)
            return
        with open(file_path, "r") as f:
            lines = f.readlines()
        for line in lines:
            execute_command(line.strip(), self.project_path, self.error_handler)

    def run_all(self):
        for file in self.files:
            self.run_file(file)

if __name__ == "__main__":
    engine = KsEngine(project_path="../examples")
    engine.run_all()
