class ErrorHandler:
    ERROR_CODES = {
        40645: "File not found. Please check the path.",
        105: "GitHub repo use warning.",
        10: "Copyright law notice."
    }

    def raise_error(self, code, file=None):
        message = self.ERROR_CODES.get(code, "Unknown error")
        if file:
            message += f" (File: {file})"
        print(f"[ERROR {code}] {message}")
