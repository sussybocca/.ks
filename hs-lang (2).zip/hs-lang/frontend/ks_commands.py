import os

def execute_command(line, project_path, error_handler):
    """
    Executes a single KS command line.
    Supported commands:
      - import all
      - export all
      - ks rename <old> to <new>
      - ks delete <file>
      - ks hide <file>
      - ks unhide <file>
      - ks run <file>
      - ks check files
      - ks list commands
    """
    line = line.strip()

    # --- IMPORT ALL ---
    if line.startswith("import all"):
        _, *files = line.split()
        for f in files:
            path = os.path.join(project_path, f)
            if not os.path.exists(path):
                error_handler.raise_error(40645, f)
            else:
                print(f"[IMPORT] {f}")

    # --- EXPORT ALL ---
    elif line.startswith("export all"):
        _, *files = line.split()
        for f in files:
            print(f"[EXPORT] {f} (logic can be added)")

    # --- RENAME ---
    elif line.startswith("ks rename"):
        parts = line.split()
        if len(parts) >= 4 and parts[2] == "to":
            old_name = parts[1]
            new_name = parts[3]
            old_path = os.path.join(project_path, old_name)
            new_path = os.path.join(project_path, new_name)
            if not os.path.exists(old_path):
                error_handler.raise_error(40645, old_name)
            else:
                os.rename(old_path, new_path)
                print(f"[RENAME] {old_name} -> {new_name}")
        else:
            print("[ERROR] Invalid ks rename syntax. Use: ks rename <old> to <new>")

    # --- DELETE ---
    elif line.startswith("ks delete"):
        parts = line.split()
        if len(parts) >= 3:
            file_name = parts[2]
            path = os.path.join(project_path, file_name)
            if not os.path.exists(path):
                error_handler.raise_error(40645, file_name)
            else:
                os.remove(path)
                print(f"[DELETE] {file_name}")
        else:
            print("[ERROR] Invalid ks delete syntax. Use: ks delete <file>")

    # --- HIDE ---
    elif line.startswith("ks hide"):
        parts = line.split()
        if len(parts) >= 3:
            file_name = parts[2]
            path = os.path.join(project_path, file_name)
            if not os.path.exists(path):
                error_handler.raise_error(40645, file_name)
            else:
                hidden_path = path + ".hidden"
                os.rename(path, hidden_path)
                print(f"[HIDE] {file_name} -> {hidden_path}")
        else:
            print("[ERROR] Invalid ks hide syntax. Use: ks hide <file>")

    # --- UNHIDE ---
    elif line.startswith("ks unhide"):
        parts = line.split()
        if len(parts) >= 3:
            file_name = parts[2]
            path = os.path.join(project_path, file_name)
            if path.endswith(".hidden") and os.path.exists(path):
                unhidden_path = path.replace(".hidden", "")
                os.rename(path, unhidden_path)
                print(f"[UNHIDE] {file_name} -> {unhidden_path}")
            else:
                print(f"[INFO] File not hidden or does not exist: {file_name}")
        else:
            print("[ERROR] Invalid ks unhide syntax. Use: ks unhide <file>")

    # --- RUN ---
    elif line.startswith("ks run"):
        parts = line.split()
        if len(parts) >= 3:
            file_name = parts[2]
            path = os.path.join(project_path, file_name)
            if os.path.exists(path):
                with open(path, "r") as f:
                    commands = f.readlines()
                print(f"[RUN] Executing {file_name}...")
                for cmd in commands:
                    execute_command(cmd.strip(), project_path, error_handler)
            else:
                error_handler.raise_error(40645, file_name)
        else:
            print("[ERROR] Invalid ks run syntax. Use: ks run <file>")

    # --- CHECK FILES ---
    elif line.startswith("ks check files"):
        all_files = os.listdir(project_path)
        ks_files = [f for f in all_files if f.endswith(".ks")]
        print(f"[CHECK FILES] KS files in project: {ks_files}")

    # --- LIST COMMANDS ---
    elif line.startswith("ks list commands"):
        commands_list = [
            "import all", "export all", "ks rename <old> to <new>", "ks delete <file>",
            "ks hide <file>", "ks unhide <file>", "ks run <file>", "ks check files"
        ]
        print("[COMMANDS] " + ", ".join(commands_list))

    # --- UNKNOWN COMMAND ---
    else:
        print(f"[UNKNOWN COMMAND] {line}")
