import os
import sys
import http.server
import socketserver
from urllib.parse import unquote

# Add frontend folder and parent folder to sys.path
sys.path.append(os.path.dirname(__file__))         # frontend
sys.path.append(os.path.dirname(os.path.dirname(__file__)))  # root folder (contains backend)

from ks_commands import ks_command_menu

PORT = 5500
DIRECTORY = os.path.join(os.path.dirname(__file__), "../examples")

class KSHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        path = unquote(self.path[1:])
        if path.endswith(".ks"):
            file_path = os.path.join(DIRECTORY, path)
            if os.path.exists(file_path):
                ks_command_menu(file_path)  # Show menu when accessed
                self.send_response(200)
                self.send_header("Content-type", "text/plain")
                self.end_headers()
                with open(file_path, "r") as f:
                    self.wfile.write(f.read().encode())
            else:
                self.send_error(404, f"File not found: {path}")
        else:
            super().do_GET()

os.chdir(DIRECTORY)
with socketserver.TCPServer(("", PORT), KSHandler) as httpd:
    print(f"Serving KS files at http://localhost:{PORT}")
    httpd.serve_forever()
