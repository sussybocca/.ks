const express = require("express");
const path = require("path");

const app = express();
const PORT = 5500;

// Serve the examples folder
app.use(express.static(path.join(__dirname, "../examples")));

// Allow opening .ks files in the browser like .html
app.get("/*.ks", (req, res) => {
  res.sendFile(path.join(__dirname, "../examples", req.path));
});

app.listen(PORT, () => {
  console.log(`Frontend .ks files served at http://localhost:${PORT}`);
});
