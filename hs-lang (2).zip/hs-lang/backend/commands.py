import os

def execute_command(line, project_path, error_handler):
    if line.startswith("import all"):
        _, *files = line.split()
        for f in files:
            path = os.path.join(project_path, f)
            if not os.path.exists(path):
                error_handler.raise_error(40645, f)
            else:
                print(f"[IMPORT] {f}")

    elif line.startswith("export all"):
        _, *files = line.split()
        for f in files:
            print(f"[EXPORT] {f}")

    elif line.startswith("ks rename"):
        parts = line.split()
        old_name, new_name = parts[2], parts[4]
        old_path = os.path.join(project_path, old_name)
        new_path = os.path.join(project_path, new_name)
        if not os.path.exists(old_path):
            error_handler.raise_error(40645, old_name)
        else:
            os.rename(old_path, new_path)
            print(f"[RENAME] {old_name} -> {new_name}")

    elif line.startswith("ks delete"):
        file_name = line.split()[2]
        path = os.path.join(project_path, file_name)
        if not os.path.exists(path):
            error_handler.raise_error(40645, file_name)
        else:
            os.remove(path)
            print(f"[DELETE] {file_name}")

    elif line.startswith("ks list commands"):
        commands = [
            "import all", "e
